﻿define("epi-ecf-ui/contentediting/editors/BundleEntryCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/topic",

    // ecf-ui
    "../ModelSupport",
    "../viewmodel/EntryRelationCollectionEditorModel",
    "./LinkEditEditor",
    "./_BaseEntryCollectionEditorGrid",
    "./_GroupDefinitionEditorMixin",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.bundleentrycollectioneditor"
],
function (
    //dojo
    declare,
    topic,

    // ecf-ui
    ModelSupport,
    EntryRelationCollectionEditorModel,
    LinkEditEditor,
    _BaseEntryCollectionEditorGrid,
    _GroupDefinitionEditorMixin,

    // Resources
    resources
) {
    var collectionEditor = declare([_BaseEntryCollectionEditorGrid], {

        resources: resources,

        modelType: EntryRelationCollectionEditorModel,

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.packageContent, ModelSupport.contentTypeIdentifier.productContent, ModelSupport.linkTypeIdentifier.relation],

        relationType: ModelSupport.relationType.bundleEntry,

        deleteConfirmationTitle: resources.deleteconfirmation.title,

        deleteConfirmationDescription: resources.deleteconfirmation.description

    });

    return declare([LinkEditEditor, _GroupDefinitionEditorMixin], {

        resources: resources,

        gridCollectionType: collectionEditor
    });
});
