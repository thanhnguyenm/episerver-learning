﻿define("epi-ecf-ui/widget/viewmodel/DiscountTreeStoreModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/promise/all",
    "dojo/Stateful",
    "dojo/when",
// dijit
    "dijit/Destroyable",
// epi
   "epi/string",
   "epi/dependency",
// epi-cms
    "epi-cms/core/ContentReference",
// resources
   "epi/i18n!epi/nls/commerce.widget.marketingtoolbar"
], function (
    array,
    declare,
    all,
    Stateful,
    when,
// dijit
    Destroyable,
// epi
   epiString,
   dependency,
// epi-cms
    ContentReference,
// resources
   sharedResources
) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Represents the store model for DiscountTree
        //
        // tags:
        //      internal

        // store: [protected] dojo.store.api.Store
        //      Underlying store that will be queried for tree items.
        store: null,

        // root: [protected]
        //      The root content link.
        root: undefined,

        // excludedLink: [public] String
        //      Content reference of the excluded discount.
        excludedLink: null,

        // checkedItems: [public] ContentLink Array
        //      List of checked content links.
        checkedItems: null,

        postscript: function () {
            this.inherited(arguments);

            // var registry = dependency.resolve("epi.storeregistry");
            // this.store = registry.get("epi.commerce.promotions");
        },

        _excludedLinkSetter: function (value) {
            this._updateContentDisableState(value, true);
            if (ContentReference.compareIgnoreVersion(this.excludedLink, value)) {
                return;
            }

            // enable the old one
            this._updateContentDisableState(this.excludedLink, false);

            this.excludedLink = value;
        },

        _updateContentDisableState: function (contentLink, disabled) {
            if (contentLink) {
                when(this.store.get(contentLink), function (content) {
                    if (content) {
                        content.disabled = disabled;
                        this.onChange(content); // by triggering onChange, the tree will update the node to reflect item's changes.
                    }
                }.bind(this));
            }
        },

        _searchTextSetter: function (queryText) {
            var self = this;

            if (!epiString.isNullOrEmpty(queryText)) {
                queryText = queryText.trim().toLowerCase();
            }
            
            when(this._queryChildren(this.root)).then(function (campaigns) {
                all(campaigns.map(function (campaign) {
                    return when(self._queryChildren(campaign.contentLink)).then(function (promotions) {
                        var isEmptySearchText = epiString.isNullOrEmpty(queryText);
                        var hasVisiblePromotion = isEmptySearchText;

                        // hide unmatched promotions
                        promotions.forEach(function (promotion) {
                            if (isEmptySearchText) {
                                self._setContentHidden(promotion, false);
                            } else {
                                var isMatched = promotion.name.toLowerCase().indexOf(queryText) >= 0;
                                self._setContentHidden(promotion, !isMatched);
                                if (isMatched && !hasVisiblePromotion) {
                                    hasVisiblePromotion = true;
                                }
                            }
                        });

                        // hide campaigns which do not have any matched promotion.
                        self._setContentHidden(campaign, !hasVisiblePromotion);
                    });
                })).then(function () {
                    self.set("visibleCampaigns", array.filter(campaigns, function (campaign) {
                        return !campaign.hidden;
                    }));
                });
            });
        },

        _setContentHidden: function (content, hidden) {
            if (content.hidden !== hidden) {
                content.hidden = hidden;
                this.onChange(content);
            }
        },

        _checkedItemsSetter: function (value) {
            this.checkedItems = value;
        },

        _queryChildren: function (parentLink) {
            return this.store.query({ referenceId: parentLink, query: "getchildren" });
        },

        getRoot: function (onItem) {
            // summary:
            //      Calls onItem with the root item for the tree, possibly a fabricated item.

            return when(this.store.get(this.root), function (item) {
                item.label = sharedResources.allcampaigns;
                item.disabled = false; // root node is always available for selecting
                item.selected = this._isNodeContentSelected(item);
                onItem(item);
            }.bind(this));
        },

        mayHaveChildren: function (item) {
            // summary:
            //      Tells if an item has or may have children.  Implementing logic here
            //      avoids showing +/- expando icon for nodes that we know don't have children.
            //      (For efficiency reasons we may not want to check if an element actually
            //      has children until user clicks the expando node)

            return item.hasChildren;
        },

        getChildren: function (parentItem, onComplete) {
            // summary:
            //      Calls onComplete() with array of child items of given parent item, all loaded.

            var self = this,
                query = this._queryChildren(this.getIdentity(parentItem)),
                listener = function(obj, removedFrom, insertedInto){
                    self.onChange(obj);

                    when(query, function (children) {

                        var hasChildren = children && children.length > 0;

                        if (parentItem.hasChildren !== hasChildren) {
                            parentItem.hasChildren = hasChildren;
                            self.onChange(parentItem);
                        }

                        self.onChildrenChange(parentItem, children);
                    });

                    var removingItem = insertedInto === -1;
                    if (!removingItem && self.mayHaveChildren(obj)) {
                        when(self._queryChildren(obj.contentLink)).then(function (children) {
                            self.onChildrenChange(obj, children);
                        });
                    }
                },
                results = query;

            // Setup listener in case children list changes, or the item(s) in the children list are updated in some way.
            if (results.observe) {
                this.own(results.observe(listener, true));
            }

            return when(results).then(function (children) {
                array.forEach(children, function (content) {
                    content.disabled = this._isNodeContentDisabled(content, this.excludedLink);
                    content.selected = this._isNodeContentSelected(content);
                }, self);

                parentItem.children = children;
                onComplete(children);
            });
        },

        _isNodeContentDisabled: function (content, excludedLink) {
            return ContentReference.compareIgnoreVersion(content.contentLink, excludedLink);
        },

        _isNodeContentSelected: function (content) {
            return array.some(this.checkedItems, function (item) {
                return ContentReference.compareIgnoreVersion(item.contentLink, this.root) ||
                       ContentReference.compareIgnoreVersion(content.parentLink, item.contentLink) ||
                       ContentReference.compareIgnoreVersion(content.contentLink, item.contentLink);
            }, this);
        },

        getIdentity: function (item) {
            // summary:
            //      Returns identity for an item

            return item.contentLink;
        },

        getLabel: function (item) {
            // summary:
            //      Get the label for an item
            if (ContentReference.compareIgnoreVersion(item.contentLink, this.root)) {
                return item.label;
            }
            return item.name;
        }
    });
});