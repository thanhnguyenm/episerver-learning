require({
  cache: {
    'url:epi-forms/widget/templates/FormsData.html': "<div class=\"epi-forms-dataView\" style=\"width: 100%; height: 100%;\">\r\n    <div data-dojo-attach-point=\"mainLayoutContainer\" data-dojo-type=\"epi/shell/layout/PreserveRatioBorderContainer\" data-dojo-props=\"gutters: false, livesplitters: false\" style=\"width: 100%; height: 100%\">\r\n\r\n        <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-props=\"region:'top'\">\r\n            <div data-dojo-attach-point=\"toolbarArea\"></div>\r\n            <div class=\"epi-listingTopContainer\">\r\n                <h1 class=\"dijitInline\">${res.heading}</h1>\r\n            </div>\r\n        </div>\r\n        <div data-dojo-attach-point=\"editLayoutContainer\" data-dojo-type=\"epi/shell/layout/CardContainer\" data-dojo-props=\"region: 'center', layoutPriority: 100\">\r\n            <div data-dojo-attach-point=\"stackContainer\">\r\n                <!-- doLayout=\"false\" for flexible height -->\r\n                <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-props=\"region:'center', fitContainer: true\">\r\n                    <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-attach-point=\"messageContentPane\"></div>\r\n                    <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-attach-point=\"contentPane\">\r\n                        <div class=\"epi-toolbarGroupContainer\">\r\n                            <div class=\"epi-forms-submissions__search-criteria\" data-dojo-attach-point=\"searchCriteria\">\r\n                                <div class=\"epi-forms-dataViewHeader clearfix\">\r\n                                    <div class=\"dijit dijitReset dijitInline\">\r\n                                        <div id=\"filterText_${id}\" class=\"dijitTextBox\" data-dojo-attach-point=\"filterText\" placeholder=${res.search} data-dojo-type=\"dijit/form/TextBox\"></div>\r\n                                        <div id=\"columnSelect_${id}\" class=\"epi-forms-submissions__column-filter\" data-dojo-attach-point=\"columnSelect\" data-dojo-type=\"dijit/form/Select\"></div>\r\n                                    </div>\r\n\r\n                                    <div class=\"dijit dijitReset dijitInline\">\r\n                                        <label for=\"beginDate_${id}\">${res.begindate}</label>\r\n                                        <div id=\"beginDate_${id}\" data-dojo-attach-point=\"beginDate\" data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\"></div>\r\n                                    </div>\r\n                                    <div class=\"dijit dijitReset dijitInline\">\r\n                                        <label for=\"endDate_${id}\">${res.enddate}</label>\r\n                                        <div id=\"endDate_${id}\" data-dojo-attach-point=\"endDate\" data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\"></div>\r\n                                    </div>\r\n                                    <div class=\"dijit dijitReset dijitInline epi-forms-submissions__finalized-filter\">\r\n                                        <div id=\"finalizedOnly_${id}\" class=\"dijitCheckbox\" data-dojo-attach-point=\"finalizedOnly\" data-dojo-type=\"dijit/form/CheckBox\" type=\"checkbox\"></div>\r\n                                        <label for=\"finalizedOnly_${id}\">${res.finalizedonly}</label>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"epi-forms-dataViewHeader floatLeft\">\r\n                                    <button data-dojo-attach-point=\"searchButton\" data-dojo-type=\"dijit/form/Button\" type=\"button\" data-dojo-attach-event=\"onClick:_onSearch\">${res.search}</button>\r\n                                </div>\r\n                                <div class=\"epi-forms-dataViewHeader floatRight\" data-dojo-attach-point=\"trailingNode\">\r\n                                    <div data-dojo-attach-point=\"exportSelector\" data-dojo-type=\"epi-forms/widget/ExportDropDownButton\"></div>\r\n                                    <button data-dojo-attach-point=\"deleteSelectedButton\" data-dojo-type=\"dijit/form/Button\" type=\"button\" data-dojo-props=\"iconClass:'epi-iconTrash'\" title=\"${res.deleteselecteditems}\"></button>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"epi-form-selectAllNotification\" data-dojo-attach-point=\"selectNotificationContainerNode\">\r\n                            <span data-dojo-attach-point=\"selectionInfo\"></span>\r\n                            <a data-dojo-attach-point=\"extraSelectLink\"></a>\r\n                        </div>\r\n                        <div data-dojo-attach-point=\"gridContainerNode\"></div>\r\n                        <div data-dojo-attach-point=\"chartContainerNode\"></div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"
  }
});

define("epi-forms/widget/FormsData", ["dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/_base/connect", "dojo/aspect", "dojo/query", "dojo/dom-construct", "dojo/dom-class", "dojo/dom-style", "dojo/string", "dojo/when", // dijit
"dijit/_TemplatedMixin", "dijit/_WidgetsInTemplateMixin", "dijit/_Widget", "dijit/layout/ContentPane", // used in template
"dijit/layout/StackContainer", // used in template
"dijit/form/Button", // used in template
"dijit/form/CheckBox", //used in template
// dojox
"dojox/widget/Standby", "dojox/charting/Chart", "dojox/charting/themes/MiamiNice", "dojox/charting/plot2d/Columns", "dojox/charting/plot2d/Markers", "dojox/charting/axis2d/Default", "dojox/charting/action2d/Tooltip", "dojox/html/entities", // dgrid
"dgrid/OnDemandGrid", "dgrid/Selection", "dgrid/Keyboard", "dgrid/extensions/ColumnResizer", "dgrid/selector", // epi
"epi/datetime", "epi/shell/widget/_ModelBindingMixin", "epi/shell/dgrid/Formatter", "epi/shell/dgrid/util/misc", "epi-cms/contentediting/ContentActionSupport", "epi-cms/contentediting/StandardToolbar", "epi/shell/widget/SearchBox", "epi/shell/widget/DateTimeSelectorDropDown", "epi/shell/widget/dialog/Confirmation", "epi/shell/layout/CardContainer", "epi/shell/layout/PreserveRatioBorderContainer", "epi/shell/XhrWrapper", // epi-addons
"epi-forms/dgrid/Formatters", "epi-forms/ModuleSettings", "epi-forms/widget/ExportDropDownButton", "epi-forms/widget/viewmodels/FormsDataViewModel", // resources
"epi/i18n!epi/cms/nls/episerver.forms.formdataview", "dojo/text!./templates/FormsData.html"], function (array, declare, lang, connect, aspect, query, domConstruct, domClass, domStyle, string, when, // dijit
_TemplatedMixin, _WidgetsInTemplateMixin, _Widget, ContentPane, // used in template
StackContainer, // used in template
Button, // used in template
CheckBox, // used in template
// dojox
Standby, Chart, theme, Columns, Markers, Default, Tooltip, HtmlEntities, // dgrid
OnDemandGrid, DgridSelection, Keyboard, ColumnResizer, selector, // epi
epiDateTime, _ModelBindingMixin, Formatter, GridMiscUtil, ContentActionSupport, StandardToolbar, SearchBox, DateTimeSelectorDropDown, Confirmation, CardContainer, PreserveRatioBorderContainer, XhrWrapper, // epi-addons
Formatters, ModuleSettings, ExportDropDownButton, FormsDataViewModel, // resources
res, template) {
  // Component to view data in grid, and exporting buttons
  return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
    res: res,
    templateString: template,
    modelClass: FormsDataViewModel,
    //bug: chart.resize() increase chart height by 3px each time it called
    _shouldResizeChart: true,
    //workaround: flag to avoid resize chart when UI have no update
    // xhrHandler: [private] Object
    //  The xhr implementation to use when requesting data. Defaults to epi.shell.XhrWrapper
    _xhrHandler: new XhrWrapper(),
    _dateTimeFormatType: "DateTime",
    //_datetimeFormatType: "DateTime",
    _linkFormatType: "Link",
    _checkedFormatType: "Checked",
    // _lastQueryParam: [private] Object
    //  Contains last query parameters (beginDate, endDate, finalizedOnly),
    //  this variable will be updated when user click on Search button.
    _lastQueryParam: null,
    selectAllCheckbox: new CheckBox(),
    // modelBindingMap: [protected] Object
    //      Contains information which is used for mapping properties between View and ViewModel.
    modelBindingMap: {
      query: ["query"],
      chartData: ["chartData"],
      beginDate: ["beginDate"],
      endDate: ["endDate"],
      finalizedOnly: ["finalizedOnly"],
      columnSelect: ["columnSelect"],
      filterText: ["filterText"]
    },
    postCreate: function postCreate() {
      this.inherited(arguments);
      this.toolbar = new StandardToolbar();
      this.toolbar.placeAt(this.toolbarArea, "first");
      var model = new this.modelClass();
      this.set("model", model);

      this._setupExportDropDownButton();

      this.selectAllCheckbox.startup();
      this.deleteSelectedButton.set("disabled", true);
      this.selectAllCheckbox.set("title", this.res.selectalltooltip);
      this.own(this.selectAllCheckbox.on("change", lang.hitch(this, this._selectAll)), this.deleteSelectedButton.on("click", lang.hitch(this, function () {
        this._onDelete();
      })), connect.connect(this, "resize", lang.hitch(this, function () {
        this.mainLayoutContainer.resize();
        this.contentPane.resize();
      })), connect.connect(this.searchCriteria, "keypress", lang.hitch(this, function (event) {
        if (event.keyCode === 13) {
          this._onSearch();
        }
      })), connect.connect(this.extraSelectLink, "click", lang.hitch(this, function () {
        this._forceSelectAll();
      })), connect.connect(this.contentPane, "resize", lang.hitch(this, function () {
        if (this._chart) {
          this._chart.resize();
        }
      })));
    },
    updateView: function updateView(data, context, additionalParams) {
      when(this.model.contentDataStore.get(context.id), lang.hitch(this, function (content) {
        if (!ContentActionSupport.hasAccess(content.accessMask, ModuleSettings.minimumAccessRightLevelToReadFormData)) {
          this._updateToolbar(data, context);

          this._toggleMessageContentPane(true);

          this.messageContentPane.set("content", string.substitute("<span class='dijitContentPaneError'><span class='dijitInline dijitIconError'></span>${accessdenied}</span>", this.res));
          return;
        }

        if (data && data.skipUpdateView) {
          return;
        }

        this._updateToolbar(data, context);

        this._toggleMessageContentPane(false); // need to redraw chart when the view is shown


        if (data && data.forceContextChange === true) {
          this._updateChart(null, null);
        } else {
          var beginDate = epiDateTime.transformDate(this.beginDate.get("value")),
              endDate = epiDateTime.transformDate(this.endDate.get("value"));

          this._updateChart(beginDate, endDate);
        }
      }));
    },
    destroy: function destroy() {
      // summary:
      //      Destroy the object.
      // tags:
      //      public, extensions
      this._destroyChildWidgets();

      this.inherited(arguments);
    },
    _destroyChildWidgets: function _destroyChildWidgets() {
      // summary:
      //      Destroy children widget
      // tags:
      //      private
      if (this._standby) {
        this._standby.destroyRecursive();

        this._standby = null;
      }

      if (this._grid) {
        this._grid.destroy();

        this._grid = null;
      }
    },
    _setupExportDropDownButton: function _setupExportDropDownButton() {
      // summary:
      //      Build menu items for export drop-down button. The list of registered exporters (get from server side) will be list of items here
      // tags:
      //      private
      this._xhrHandler.xhrGet({
        url: ModuleSettings.listOfDataExportersUrl,
        handleAs: "json"
      }).then(lang.hitch(this, function (arrExporters) {
        var thisFormDataComponent = this; // transform the array of exporters into selectionItems

        var changedArray = array.map(arrExporters, function (exporter) {
          exporter.onExport = lang.hitch(thisFormDataComponent, thisFormDataComponent._onExport);
          return exporter;
        });
        this.exportSelector.set("menuItems", changedArray);
      }));
    },
    _refresh: function _refresh(queryObject) {
      // summary:
      //      Destroy the old dgrid, get new data and re-render dgrid
      // tags:
      //      private
      if (this._grid) {
        this._grid.cleanup();

        this._grid.destroy();
      }

      if (this._standby) {
        this._standby.destroyRecursive();

        this._standby = null;
      }

      this.selectAllCheckbox.set("checked", false);
      this.deleteSelectedButton.set("disabled", true);
      domStyle.set(this.selectNotificationContainerNode, "display", "none");
      when(this.model.getColumns(), lang.hitch(this, function (columns) {
        if (!columns) {
          return;
        }

        var source = [{
          label: res.searchallcolumns,
          value: ""
        }];
        columns.forEach(function (item) {
          lang.mixin(item, {
            sortable: true
          });

          if (item.formatType == this._dateTimeFormatType) {
            // inject formater for SubmitTime field
            lang.mixin(item, {
              formatters: [Formatters.dateTimeFormatter, GridMiscUtil.ellipsis]
            });
          } else if (item.formatType == this._linkFormatType) {
            // inject formater for link field
            lang.mixin(item, {
              formatters: [Formatters.embededLinksFormatter]
            });
          } else if (item.formatType == this._checkedFormatType) {
            lang.mixin(item, {
              formatters: [Formatters.checkedFormatter]
            });
          } else {
            lang.mixin(item, {
              formatters: [Formatters.removeNullValueFormatter, Formatters.encodeAndEllipsisFormatter]
            });
          }

          if (item.isSearchable) {
            source.push({
              label: HtmlEntities.encode(item.label),
              value: item.field
            });
          }
        }, this);
        var currentSelectedColumn = this.columnSelect.get("value");
        this.columnSelect.set("options", source); // rebind dropdown source

        this.columnSelect.set("value", currentSelectedColumn || ""); // insert selector column

        var selectorColumn = selector({
          label: "",
          selectorType: "checkbox",
          className: "epi-columnVeryNarrow"
        });
        var self = this;
        this.own(aspect.after(selectorColumn, "renderHeaderCell", function (th) {
          self.selectAllCheckbox.set("class", "epi-forms-dataViewHeader-selectAllCheckbox");
          domConstruct.place(self.selectAllCheckbox.domNode, th, "only");
        }, true));
        columns.splice(0, 0, selectorColumn);
        var gridClass = declare([OnDemandGrid, DgridSelection, Keyboard, Formatter, ColumnResizer]);
        this._grid = new gridClass({
          store: this.model.store,
          columns: columns,
          minWidth: 100,
          noDataMessage: this._getNoDataMessage(),
          selectionMode: "none",
          allowSelectAll: false
        });

        this._grid.styleColumn("SYSTEMCOLUMN_SubmissionId", "display: none;"); // hide the submissionId column through its Id


        domConstruct.place(this._grid.domNode, this.gridContainerNode);
        this._standby = new Standby({
          target: this.stackContainer,
          color: "#fff"
        }).placeAt(document.body);

        this._standby.startup();

        this.own(this._grid.on("dgrid-select", lang.hitch(this, this._toggleButtonsState)), this._grid.on("dgrid-deselect", lang.hitch(this, this._toggleButtonsState)), this._grid.on("dgrid-sort", lang.hitch(this, function () {
          this._shouldResizeChart = false;
        })), this._grid.on("dgrid-refresh-complete", lang.hitch(this, function (event) {
          this.forcedSelectAll = false;
          this._grid.allSelected = false;

          if (this._shouldResizeChart) {
            this._resizeChart();
          } else {
            this._shouldResizeChart = true;
          } // show/hide Export, Delete buttons depend on data


          domStyle.set(this.trailingNode, "display", this._grid._total === 0 ? "none" : "");
          domStyle.set(this.selectAllCheckbox.domNode, "display", this._grid._total === 0 ? "none" : ""); // add class for gird header inside "Form submissions"

          if (this.gridContainerNode != null) {
            query('[role="columnheader"]>div', this.gridContainerNode).forEach(function (cell) {
              domClass.add(cell, "dojoxEllipsis");
            });
          }
        })), aspect.after(this._grid, "_processScroll", lang.hitch(this, function () {
          var rowCount = this._getGridRows().length;

          var selectionCount = this._getSelectedItems().length;

          var allSelected = this._grid.allSelected === true || rowCount === selectionCount && selectionCount > 0;

          this._updateSelectAllCheckbox(allSelected);
        })));

        this._grid.set("query", queryObject);
      }));
    },
    _selectAll: function _selectAll(isChecked) {
      // summary:
      //      Handler when Select All checkbox is clicked
      // tags:
      //      private
      if (isChecked) {
        this._grid.selection = {}; // do this to clear out pages from previous sorts

        this._selectAllRowsInCurrentView();

        this.selectAllCheckbox.set("title", this.res.deselectalltooltip);

        this._updateSelectionNotificationBar();
      } else {
        this.selectAllCheckbox.set("title", this.res.selectalltooltip);

        this._clearAllSelections();
      }
    },
    _selectAllRowsInCurrentView: function _selectAllRowsInCurrentView() {
      // summary:
      //      Select all rows of dgrid in current view.
      // tags:
      //      private
      array.forEach(this._getGridRows(), lang.hitch(this, function (item) {
        this._grid.select(item);
      }));
    },
    _getGridRows: function _getGridRows() {
      // summary:
      //      Get all rows of the dgrid in current view.
      // tags:
      //      private
      var rows = [];
      query(".dgrid-row", this._grid.domNode).forEach(lang.hitch(this, function (node) {
        var row = this._grid.row(node);

        rows.push(row);
      }));
      return rows;
    },
    _updateSelectionNotificationBar: function _updateSelectionNotificationBar() {
      // summary:
      //      Update selection info on notification bar
      // tags:
      //      private
      var selectionCount = Object.keys(this._grid.selection || {}).length;
      var numberOfSelections = this.forcedSelectAll ? this._grid._total : selectionCount;
      this.selectionInfo.innerHTML = string.substitute(res.selectioninfo, [numberOfSelections]);

      if (this.forcedSelectAll) {
        this.extraSelectLink.innerHTML = res.clearselectionlink;
      } else if (selectionCount < this._grid._total) {
        this.extraSelectLink.innerHTML = string.substitute(res.extraselectionlink, [this._grid._total]);
      } else {
        this.extraSelectLink.innerHTML = "";
      }

      domStyle.set(this.selectNotificationContainerNode, "display", "");
      this.showSelectionNotificationBar = true;
    },
    _clearAllSelections: function _clearAllSelections() {
      // summary:
      //     Clear all selection
      // tags:
      //      private
      this._grid.clearSelection();

      this._hideSelectionNotificationBar();
    },
    _hideSelectionNotificationBar: function _hideSelectionNotificationBar() {
      // summary:
      //    Hide selection notification bar
      // tags:
      //    private
      if (this.showSelectionNotificationBar) {
        domStyle.set(this.selectNotificationContainerNode, "display", "none");
        this.showSelectionNotificationBar = false;
      }
    },
    _forceSelectAll: function _forceSelectAll() {
      // summary:
      //     Force select all submissions, include unloaded records
      // tags:
      //      private
      if (this.forcedSelectAll) {
        this.forcedSelectAll = false;
        this._grid.allSelected = false;

        this._clearAllSelections();

        this._updateSelectAllCheckbox(false);
      } else {
        this.forcedSelectAll = true;
        this._grid.allSelected = true;

        this._selectAllRowsInCurrentView();

        this._updateSelectionNotificationBar();
      }
    },
    _toggleButtonsState: function _toggleButtonsState(
    /*Object*/
    event) {
      // summary:
      //      Toggle state of buttons.
      // event: [Object]
      //      Event object of dgrid: 'dgrid-select' and 'dgrid-deselect'.
      // tags:
      //      private
      if (event.type === "dgrid-deselect") {
        this.forcedSelectAll = false;
        this._grid.allSelected = false;
      }

      var rowCount = this._getGridRows().length;

      var selectionCount = this._getSelectedItems().length;

      var allSelected = this._grid.allSelected || rowCount === selectionCount && selectionCount > 0;
      this.deleteSelectedButton.set("disabled", selectionCount <= 0);

      this._updateSelectAllCheckbox(allSelected);

      if (allSelected && this.showSelectionNotificationBar) {
        this._updateSelectionNotificationBar();
      } else {
        this._hideSelectionNotificationBar();
      }
    },
    _updateSelectAllCheckbox: function _updateSelectAllCheckbox(checked) {
      // summary:
      //      Update selectAll checkbox without raising "change" event.
      // tags:
      //      private
      // set checked for select all checkbox without trigger 'change' event
      this.selectAllCheckbox._onChangeActive = false;
      this.selectAllCheckbox.set("checked", checked);
      this.selectAllCheckbox._onChangeActive = true;
      this.selectAllCheckbox.set("title", checked == true ? this.res.deselectalltooltip : this.res.selectalltooltip);
    },
    _onSearch: function _onSearch() {
      // summary:
      //      Search submission in a specified date time range
      // tags:
      //      private
      // TECHNOTE:
      //      Defers clicking on the Search button multiple times.
      this.searchButton.set("disabled", true);
      setTimeout(lang.hitch(this, function () {
        this.searchButton.set("disabled", false);
      }), 1000);
      domStyle.set(this.selectAllCheckbox.domNode, "display", "none");

      this._showStandby(true);

      this._lastQueryParam = {
        beginDate: epiDateTime.transformDate(this.beginDate.get("value")),
        endDate: epiDateTime.transformDate(this.endDate.get("value")),
        finalizedOnly: this.finalizedOnly.checked,
        columnSelect: this.columnSelect.get("value"),
        filterText: this.filterText.get("value")
      };
      when(this.model.getCurrentContext(), lang.hitch(this, function (context) {
        this._updateChart(this._lastQueryParam.beginDate, this._lastQueryParam.endDate, this._lastQueryParam.finalizedOnly, this._lastQueryParam.columnSelect, this._lastQueryParam.filterText);

        var query = lang.mixin({
          parent: context.id
        }, this._lastQueryParam);

        this._refresh(query);
      }));
    },
    _onExport: function _onExport(exporter) {
      // summary:
      //      Exporting submission data within a specified date time range
      // tags:
      //      private
      this._showStandby(true);

      var hideStandby = lang.hitch(this, function () {
        this._showStandby(false);
      }); // exporting bases on filter, selected items take higher priority

      var selection = this._getSelectedItems();

      if (selection.length > 0 && !this.forcedSelectAll) {
        this.model.exportData(exporter, selection, null, null, false, null, null, hideStandby);
      } else {
        var params = this._lastQueryParam || {};
        this.model.exportData(exporter, null, params.beginDate, params.endDate, params.finalizedOnly, params.columnSelect, params.filterText, hideStandby);
      }
    },
    _onDelete: function _onDelete() {
      // summary:
      //      Deleting submission data for checked items
      // tags:
      //      private
      this._showConfirmationDialog(this.res.deleteconfirmation, lang.hitch(this, function (confirm) {
        if (confirm) {
          this._showStandby(true);

          if (this.forcedSelectAll) {
            when(this.model.deleteByQuery(this._grid.query), lang.hitch(this, function (result) {
              if (result.isSuccess == true) {
                this._onSearch();
              }

              this._showStandby(false);
            }));
          } else {
            var selection = this._getSelectedItems();

            if (!(selection instanceof Array) || selection.length < 1) {
              return;
            }

            when(this.model.deleteData(selection), lang.hitch(this, function (result) {
              if (result.isSuccess == true) {
                this._onSearch();
              }

              this._showStandby(false);
            }));
          }
        }
      }));
    },
    _getNoDataMessage: function _getNoDataMessage() {
      // summary:
      //      Get message in case have no data.
      // tags:
      //      private
      return '<span><span class="dijitReset dijitInline">' + res.nodata + "</span></span>";
    },
    _setQueryAttr: function _setQueryAttr(
    /*Object*/
    value) {
      // summary:
      //      Set the query for fetching data from the store and fill into grid.
      // parameters:
      //      query: the query paramenter will be sent to rest store.
      // tags:
      //      private
      var query = value ? value : {
        parent: null
      };

      this._refresh(query);
    },
    _setBeginDateAttr: function _setBeginDateAttr(value) {
      // summary:
      //      set value for begin date
      this.beginDate && this.beginDate.domNode && this.beginDate.set("value", value);
    },
    _setEndDateAttr: function _setEndDateAttr(value) {
      // summary:
      //      set value for end date
      this.endDate && this.endDate.domNode && this.endDate.set("value", value);
    },
    _setFinalizedOnlyAttr: function _setFinalizedOnlyAttr(value) {
      // summary:
      //      set value for finalizedOnly
      this.finalizedOnly && this.finalizedOnly.domNode && this.finalizedOnly.set("checked", value);
    },
    _setColumnSelectAttr: function _setColumnSelectAttr(value) {
      // summary:
      //      set value for columnSelect
      this.columnSelect && this.columnSelect.domNode && this.columnSelect.set("value", value || "");
    },
    _setFilterTextAttr: function _setFilterTextAttr(value) {
      // summary:
      //      set value for finalizedOnly
      this.filterText && this.filterText.domNode && this.filterText.set("value", value);
    },
    _updateChart: function _updateChart(beginDate, endDate, finalizedOnly, columnSelect, filterText) {
      // summary:
      //      Redraw chart with new data.
      if (this._chart) {
        this._chart.destroy();

        this._chart = null;
      }

      when(this.model.getChartData(beginDate, endDate, finalizedOnly, columnSelect, filterText), lang.hitch(this, function (data) {
        if (!data) {
          return;
        }

        var itemsContainData = array.filter(data, function (item) {
          return item.value > 0;
        }); // hide grid node if there is no data

        domStyle.set(this.chartContainerNode, "display", itemsContainData.length == 0 ? "none" : "");
        var xAxisData = [];
        var labels = [];

        for (var i = 0; i < data.length; i++) {
          xAxisData.push(data[i].value);
          labels.push({
            value: i + 1,
            text: data[i].key
          });
        }

        var chart = new Chart(this.chartContainerNode);
        chart.addPlot("default", {
          type: Columns,
          markers: true,
          gap: 5
        }).addAxis("x", {
          labels: labels,
          fixLower: "major",
          fixUpper: "major",
          majorTickStep: 1,
          minorTicks: false,
          rotation: -90
        }).addAxis("y", {
          vertical: true,
          fixLower: "major",
          fixUpper: "major",
          min: 0,
          minorTicks: false
        }).setTheme(theme).addSeries("Form Submissions", xAxisData).render(); // must call chart resize to rebind tool tip to the chart

        chart.resize();
        this._chart = chart;
      }));
    },
    _resizeChart: function _resizeChart() {
      // summary:
      //      Resize chart to fit with parent
      // tags:
      //      private
      if (this._chart) {
        this._chart.resize();
      }
    },
    _showStandby: function _showStandby(visible) {
      // summary:
      //      Set standby visibility.
      // tags:
      //      private
      if (!this._standby) {
        return;
      }

      if (visible) {
        if (!this._standby.isVisible()) {
          this._standby.show();
        }
      } else {
        this._standby.hide();
      }
    },
    _getSelectedItems: function _getSelectedItems() {
      // summary:
      //    Iterate the grid items and return the selected submission id.
      var selection = [],
          selected = this._grid.selection;

      if (selected) {
        for (var rowId in selected) {
          if (selected[rowId] == true) {
            selection.push(rowId);
          }
        }
      }

      return selection;
    },
    _showConfirmationDialog: function _showConfirmationDialog(
    /*String*/
    message,
    /*Function*/
    fnConfirmCallback) {
      // summary:
      //    Configure and open the confirmation dialog.
      //
      // fnConfirmCallback:
      //    Callback function.
      //
      // tags:
      //    private
      var dialog = new Confirmation({
        description: message,
        title: this.res.heading,
        onAction: fnConfirmCallback
      });
      dialog.show();
    },
    _updateToolbar: function _updateToolbar(data, context) {
      // summary:
      //      Update global toolbar with
      //      - Current context
      //      - View configuration
      // tags:
      //      private
      this.toolbar.update({
        currentContext: context,
        viewConfigurations: {
          availableViews: data.availableViews,
          viewName: data.viewName
        }
      }); // Resize the UI after updating the toolbar.

      this.toolbar.isSetup().then(lang.hitch(this, function () {
        this.mainLayoutContainer.resize();
      }));
    },
    _toggleMessageContentPane: function _toggleMessageContentPane(
    /*Boolean*/
    show) {
      // summary:
      //      Toggle display of the message content pane
      // tags:
      //      private
      if (show) {
        domClass.remove(this.contentPane.domNode, "dijitVisible");
        domClass.add(this.contentPane.domNode, "dijitHidden");
        domClass.add(this.messageContentPane.domNode, "dijitVisible");
      } else {
        domClass.remove(this.messageContentPane.domNode, "dijitVisible");
        domClass.add(this.messageContentPane.domNode, "dijitHidden");
        domClass.add(this.contentPane.domNode, "dijitVisible");
      }
    }
  });
});