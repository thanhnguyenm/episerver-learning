define("epi-forms/contentediting/editors/ChoiceEditor", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-class", // dijit
"dijit/registry", // epi-addons
"epi-forms/contentediting/editors/_WidgetListEditor", "epi-forms/ModuleSettings"], function ( // dojo
array, declare, lang, domClass, // dijit
registry, // epi-addons
_WidgetListEditor, ModuleSettings) {
  // module:
  //      epi-forms/contentediting/editors/ChoiceEditor
  // summary:
  //      Radio button list widget.
  // tags:
  //      public
  return declare([_WidgetListEditor], {
    // _recordSeparator: [private] String
    _recordSeparator: ModuleSettings.recordSeparator,
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);

      this._setupLayout();
    },
    getCalculatedValue: function getCalculatedValue() {
      // summary:
      //      Overrided function to get calculated value of this editor.
      // returns: [Object]
      //
      // tags:
      //      public, extensions
      var selectors = this.get("itemWidgets");
      return this.selectorType === "multiple" ? this._getCheckBoxesCalculatedValue(selectors) : this._getRadioButtonsCalculatedValue(selectors);
    },
    onBlur: function onBlur() {
      // summary:
      //      When this widget loses focus. Reset unchecked items state.
      // tags:
      //      callback
      var itemWidgets = this.get("itemWidgets");

      if (!(itemWidgets instanceof Array) || itemWidgets.length <= 0) {
        return;
      }

      array.forEach(itemWidgets, lang.hitch(this, function (itemWidget) {
        var childWidgets = registry.findWidgets(itemWidget.domNode);

        if (childWidgets.length < 2) {
          return;
        }

        var firstChild = childWidgets[0];
        var checked = firstChild.get("checked");

        if (checked) {
          return;
        }

        childWidgets[1].resetErrorState && typeof childWidgets[1].resetErrorState === "function" && childWidgets[1].resetErrorState();
      }), this);
    },
    onSelectorsValueSet: function onSelectorsValueSet() {// summary:
      //      Triggered when the selectors value are set
      //
      // tags:
      //    public, callback
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _setValueAttr: function _setValueAttr(
    /*String*/
    value) {
      // summary:
      //      Set value for this editor.
      // value: [String]
      //
      // tags:
      //      protected, extensions
      this.inherited(arguments);

      this._setSelectorsValue(value);
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _setupLayout: function _setupLayout() {
      // summary:
      //      Build layout for this editor.
      // tags:
      //      private
      domClass.add(this.domNode, this.selectoryType === "multiple" ? "epi-forms-checkBoxList" : "epi-forms-radioButtonList");
    },
    _getCheckBoxesCalculatedValue: function _getCheckBoxesCalculatedValue(
    /*Array*/
    selectors) {
      // summary:
      //
      // selectors: [Array]
      //
      // returns: [String]
      //
      // tags:
      //      private
      var values = [];
      array.forEach(selectors, function (widget) {
        if (true === widget.get("selectorChecked")) {
          values.push(widget.get("selectorValue"));
        }
      }, this);
      var value = values.join(this._recordSeparator);
      return value !== "" ? value : null;
    },
    _getRadioButtonsCalculatedValue: function _getRadioButtonsCalculatedValue(
    /*Array*/
    selectors) {
      // summary:
      //
      // selectors: [Array]
      //
      // returns: [String]
      //
      // tags:
      //      private
      var selectedWidgets = array.filter(selectors, function (widget) {
        return widget.get("selectorChecked");
      });
      return selectedWidgets.length > 0 ? selectedWidgets[0].get("selectorValue") : null;
    },
    _setSelectorsValue: function _setSelectorsValue(
    /*String*/
    value) {
      // summary:
      //
      // value: [String]
      //
      // tags:
      //      private
      if (!(this.selections instanceof Array) || this.selections.length === 0) {
        return;
      }

      this._selectionsInterval && clearInterval(this._selectionsInterval);
      this._selectionsInterval = setInterval(lang.hitch(this, function () {
        var selectors = this.get("itemWidgets");

        if (selectors instanceof Array && selectors.length > 0) {
          this._selectionsInterval && clearInterval(this._selectionsInterval);
          this.selectorType === "multiple" ? this._setCheckBoxesValue(selectors, value) : this._setRadioButtonsValue(selectors, value);
          this.onSelectorsValueSet();
        }
      }), 100);
    },
    _setCheckBoxesValue: function _setCheckBoxesValue(
    /*Array*/
    selectors,
    /*String*/
    value) {
      // summary:
      //
      // selectors: [Array]
      //
      // value: [String]
      //
      // tags:
      //      private
      var values = [];

      if (value) {
        values = value.split(this._recordSeparator);
      }

      array.forEach(selectors, function (widget) {
        widget.set("selectorChecked", true === array.some(values, function (selectorValue) {
          return selectorValue === widget.get("selectorValue");
        }));
      });
    },
    _setRadioButtonsValue: function _setRadioButtonsValue(
    /*Array*/
    selectors,
    /*String*/
    value) {
      // summary:
      //
      // selectors: [Array]
      //
      // value: [String]
      //
      // tags:
      //      private
      array.forEach(selectors, function (widget) {
        var selectorValue = widget.get("selectorValue").split(this._recordFieldSeparator)[0];
        widget.set("selectorChecked", value && value.indexOf(selectorValue) === 0);
      }, this);
    }
  });
});