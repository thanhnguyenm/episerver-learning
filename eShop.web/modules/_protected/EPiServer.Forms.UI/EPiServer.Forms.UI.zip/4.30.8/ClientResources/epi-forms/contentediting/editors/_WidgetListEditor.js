define("epi-forms/contentediting/editors/_WidgetListEditor", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-class", "dojo/dom-construct", "dojo/when", // dijit
"dijit/_TemplatedMixin", "dijit/_Widget", "dijit/focus", // epi
"epi/shell/widget/_ValueRequiredMixin", // epi-forms
"epi-forms/contentediting/editors/_EditorMixin", "epi-forms/ModuleSettings"], function ( // dojo
array, declare, lang, domClass, domConstruct, when, // dijit
_TemplatedMixin, _Widget, focusUtil, // epi
_ValueRequiredMixin, // epi-forms
_EditorMixin, ModuleSettings) {
  // module:
  //      epi-forms/contentediting/editors/_WidgetListEditor
  // summary:
  //      Editor for a property
  //      Base widget for option list.
  //      Base on seletorType, this list will render the Option item (can be a radio button or a checkbox button).
  //      _WidgetListEditor render a list of row
  //      each row can be prefix with a radio or checkbox (by ChoiceItem), follow by a rowWidget
  //      rowWidget=ChoiceItemWithPreviewableText or ChoiceItemWithSelection
  // tags:
  //      protected
  return declare([_Widget, _TemplatedMixin, _ValueRequiredMixin, _EditorMixin], {
    templateString: '<section class="dijit dijitReset dijitInline"></section>',
    baseClass: "epi-forms-itemWidgetList",
    value: null,
    // _recordFieldSeparator: [private] String
    _recordFieldSeparator: ModuleSettings.recordFieldSeparator,
    constructor: function constructor() {
      this._itemWidgets = [];
    },
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    postMixInProperties: function postMixInProperties() {
      this.inherited(arguments);
      !this.itemParams && (this.itemParams = {});
      lang.mixin(this.itemParams, {
        editorModelType: this.editorModelType,
        selectorType: this.selectorType
      });
    },
    buildRendering: function buildRendering() {
      this.inherited(arguments);

      if (this.selectorContainerType) {
        array.forEach(this.selections, this._createChildItem, this);
      }
    },
    destroy: function destroy() {
      var itemWidget; // eslint-disable-next-line no-cond-assign

      while (itemWidget = this._itemWidgets.pop()) {
        itemWidget.destroyRecursive();
      }

      this.inherited(arguments);
    },
    focus: function focus() {
      // summary:
      //      Focus the widget.
      // tags:
      //      public
      try {
        if (!(this._itemWidgets instanceof Array) || this._itemWidgets.length === 0) {
          return;
        }

        var focusableNode = typeof this._itemWidgets[0].getFocusableNode === "function" && this._itemWidgets[0].getFocusableNode();

        focusableNode && focusUtil.focus(focusableNode);
      } catch (e) {
        /*quiet*/
      }
    },
    getCalculatedValue: function getCalculatedValue() {// summary:
      //      Abstract function to get calculated value of this widget.
      // returns: [Object]
      //
      // tags:
      //      public, abstract
    },
    onChange: function onChange()
    /*===== newValue =====*/
    {// summary:
      //      Callback when this widget's value is changed.
      // tags:
      //      callback
    },
    onBlur: function onBlur() {// summary:
      //      Callback when this widget loses focus.
      // tags:
      //      callback
    },
    onFocus: function onFocus() {// summary:
      //      Callback when this widget gains focus.
      // tags:
      //      callback
    },
    isValid: function isValid(isFocused) {
      // summary:
      //      Check current editor value is valid or not.
      // tags:
      //      override
      var isValid = true;
      array.forEach(this._itemWidgets, lang.hitch(this, function (itemWidget) {
        if (itemWidget && itemWidget.isValid) {
          isValid &= itemWidget.isValid();
        }
      }), this);
      return this.inherited(arguments) && isValid;
    },
    validate: function validate(
    /*Boolean*/
    isFocused) {
      // summary:
      //      Validate value of this editor before save.
      // tags:
      //      override
      var isValid = true;
      array.forEach(this._itemWidgets, lang.hitch(this, function (itemWidget) {
        if (itemWidget && itemWidget.validate) {
          isValid &= itemWidget.validate();
        }
      }), this);
      return this.inherited(arguments) && isValid;
    },
    getErrorMessage: function getErrorMessage() {
      // summary:
      //      Return message when validation fail.
      // tags:
      //      public
      return this.errorMessage;
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _getItemWidgetsAttr: function _getItemWidgetsAttr() {
      // summary:
      //      Gets collection of item widget.
      // returns: [Array]
      //      A collection of item widget.
      // tags:
      //      protected
      return this._itemWidgets;
    },
    _setValueAttr: function _setValueAttr(value) {
      // tags:
      //      protected
      this._set("value", value);
    },
    _toggleOnChangeActive: function _toggleOnChangeActive(enable) {
      // summary:
      //      Enable/disable onChange event of checkbox or radio buttons.
      // tags:
      //      protected
      array.forEach(this._itemWidgets, lang.hitch(this, function (itemWidget) {
        var selector = itemWidget._selector;
        selector._onChangeActive = enable;
      }), this);
    },
    _buildItemParams: function _buildItemParams(
    /*Object*/
    item) {
      // summary:
      //      Build the item params for the option widget
      // item: [Object]
      //      Item data object that used to build an option widget.
      // tags:
      //      protected
      var itemParams = {};

      if (this.itemParams) {
        itemParams = lang.clone(this.itemParams);
      }

      lang.mixin(itemParams, {
        item: lang.delegate(item, {
          readOnly: this.readOnly
        }),
        selectedItemValue: this.selectedItemValue,
        selectorReadOnly: this.readOnly,
        selectorValue: item.value,
        selectorText: item.text,
        searchConditions: {
          key: this._getSearchKey(item.value),
          selectedFields: this.selectedFields
        }
      });
      return itemParams;
    },
    _onSelectorChanged: function _onSelectorChanged() {
      // summary:
      //      Handle the selector value changed event
      // tags:
      //      protected
      if (!this._shouldRaiseChangedEvent()) {
        return;
      }

      this.onFocus(); // need this to make the editor start editing

      this._calculateValue();

      this.onChange(this.value);
      this.onBlur(); // for stop editing and create undo step
    },
    _shouldRaiseChangedEvent: function _shouldRaiseChangedEvent() {
      // summary:
      //      Determine whether the changed event should be raised or not.
      //      By default, it is raised.
      // tags:
      //      protected
      return true;
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _onBlur: function _onBlur() {
      this.inherited(arguments);
      this.onBlur();
    },
    _calculateValue: function _calculateValue() {
      // summary:
      //      Calculate value for this widget.
      // tags:
      //      private
      this._set("value", this.getCalculatedValue());
    },
    _createChildItem: function _createChildItem(
    /*Object*/
    item) {
      // summary:
      //      Build an option widget from the given item data object and then add it to the collection.
      // item: [Object]
      //      Item data object that used to build an option widget.
      // tags:
      //      private
      var itemParams = this._buildItemParams(item);

      when(this.getInstanceFromType(this.selectorContainerType, itemParams), lang.hitch(this, this._setupItemWidget));
    },
    _setupItemWidget: function _setupItemWidget(
    /*Object*/
    itemWidget) {
      // summary:
      //
      // itemWidget: [Object]
      //      An instance of 'dijit/_Widget' class
      // tags:
      //      protected
      if (!itemWidget) {
        return;
      }

      this._itemWidgets.push(itemWidget);

      domClass.add(itemWidget.domNode, this.itemContainerClass);
      domConstruct.place(itemWidget.domNode, this.domNode, "last");
      this.own(itemWidget.on("selectorChanged", lang.hitch(this, this._onSelectorChanged)));
    },
    _getSearchKey: function _getSearchKey(
    /*String*/
    value) {
      // summary:
      //      Gets searchable key from given value.
      // value: [String]
      //      Raw value used to extracts searchable key from.
      // returns: [String]
      //      Searchable key string.
      // tags:
      //      private
      if (value.indexOf(this._recordFieldSeparator) === -1) {
        return value;
      }

      return value.split(this._recordFieldSeparator).shift();
    }
  });
});