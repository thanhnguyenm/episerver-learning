define("epi-forms/component/FormsViewModel", [// dojo
"dojo/_base/declare", "dojo/_base/lang", // epi
"epi-cms/asset/view-model/HierarchicalListViewModel", "epi-cms/command/ShowAllLanguages", // epi-addons
"epi-forms/component/command/NewForm", "epi-forms/component/command/ViewFormData"], function ( // dojo
declare, lang, // epi
HierarchicalListViewModel, ShowAllLanguagesCommand, // epi-addons
NewFormCommand, ViewFormDataCommand) {
  // module:
  //      epi-forms/component/FormsViewModel
  // summary:
  //      Handles search and tree to list browsing widgets.
  // tags:
  //      public
  return declare([HierarchicalListViewModel], {
    _updateCommandModels: function _updateCommandModels(selectedItems) {
      // summary:
      //      Update model of create and plugin commands.
      // tags:
      //      protected
      this.inherited(arguments);

      this._commandRegistry.newForm.command.set("model", selectedItems);

      this._commandRegistry.viewData.command.set("model", selectedItems);
    },
    _selectedTreeItemsSetter: function _selectedTreeItemsSetter(selectedItems) {
      // summary:
      //      Updates the commands with the specified value and updates the list query.
      // value:
      //      The selected tree items.
      // tags:
      //      protected
      this.inherited(arguments);
      var translateDelegate = lang.hitch(this.treeStoreModel, this.treeStoreModel.translate);

      this._commandRegistry.translate.command.set("model", selectedItems);

      this._commandRegistry.translate.command.set("executeDelegate", translateDelegate);

      this._commandRegistry.newFormDefault.command.set("model", selectedItems);
    },
    _setupCommands: function _setupCommands() {
      // summary:
      //      Creates and registers the commands used.
      // tags:
      //      protected
      this.inherited(arguments);
      var customCommands = {
        newFormDefault: {
          command: new NewFormCommand({
            viewModel: this
          })
        },
        newForm: {
          command: new NewFormCommand({
            viewModel: this,
            category: "context",
            iconClass: "epi-iconSharedBlock"
          }),
          order: 2
        },
        allLanguages: {
          command: new ShowAllLanguagesCommand({
            model: this
          }),
          order: 55
        },
        viewData: {
          command: new ViewFormDataCommand({
            category: "context",
            forceContextChange: true
          }),
          order: 4
        }
      };
      this._commandRegistry = lang.mixin(this._commandRegistry, customCommands);
      this.pseudoContextualCommands.push(this._commandRegistry.newFormDefault.command);
    }
  });
});